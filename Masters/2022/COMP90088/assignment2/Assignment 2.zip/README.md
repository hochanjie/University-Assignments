Student 1:
----------
Username: chanjieh
Student Number: 961948

Student 2:
----------
Username: adesu
Student Number: 1000447