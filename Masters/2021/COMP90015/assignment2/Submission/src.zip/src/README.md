## Run the following in order (Note, best to use ip=localhost):
# Terminal 1:
java -jar Database.jar [ip] [port_number] 

# Terminal 2:
java -jar Server.jar [ip] [port_number] 

# Terminal 3:
java -jar Client.jar